import 'package:flutter/material.dart';

void main() {
  runApp(BirthdayReminderApp());
}

class BirthdayReminderApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Birthday Reminder',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false, // This removes the debug banner
      home: BirthdayListScreen(),
    );
  }
}

class BirthdayListScreen extends StatefulWidget {
  @override
  _BirthdayListScreenState createState() => _BirthdayListScreenState();
}

class _BirthdayListScreenState extends State<BirthdayListScreen> {
  List<Birthday> birthdays = [];

  @override
  void initState() {
    super.initState();
    // Initialize some dummy data
    birthdays = [
      Birthday('Noumi', DateTime(2000, 5, 24)),
      Birthday('Ali', DateTime(1995, 6, 12)),
      Birthday('Uzair', DateTime(1988, 7, 5)),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Birthday Reminder',
          style: TextStyle(color: Colors.black),
        ),
      ),
      backgroundColor: Colors.white.withOpacity(0.5),
      body: ListView.builder(
        itemCount: birthdays.length,
        itemBuilder: (context, index) {
          final birthday = birthdays[index];
          return ListTile(
            title: Text(
              birthday.name,
              style: TextStyle(color: Colors.blue),
            ),
            subtitle: Text(
              '${birthday.date.day}/${birthday.date.month}/${birthday.date.year}',
              style: TextStyle(color: Colors.blue),
            ),
            onTap: () {
              _showBirthdayNotification(birthday);
            },
          );
        },
      ),
    );
  }

  void _showBirthdayNotification(Birthday birthday) {
    // You can implement your own notification mechanism here
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Birthday Reminder',
            style: TextStyle(color: Colors.blue),
          ),
          content: Text(
            'It\'s ${birthday.name}\'s birthday!',
            style: TextStyle(color: Colors.blue),
          ),
          actions: <Widget>[
            TextButton(
              child: Text(
                'OK',
                style: TextStyle(color: Colors.blue),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

class Birthday {
  final String name;
  final DateTime date;

  Birthday(this.name, this.date);
}
